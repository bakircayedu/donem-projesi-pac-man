#include<stdio.h>
#include <unistd.h>

#define W 10

char dizi[W] = {' ',' ',' ',' ',' ',' ','#',' ','#',' '};

struct bilgiler {
	
	int skor;
	char isim[20];	
	
}kayit;


struct konum{
	
	int x;
	
}location;


void ilerle() {
			
	dizi[location.x-1] = ' ';	
	
	if(dizi[location.x] == '#') {
		
		kayit.skor++;		
	}
		
	dizi[location.x] = '@';
	location.x++;	
}


void harita() {
	
	int i;
	system("cls");
	for(i = 0; i < 10; i++) {
		
		printf("%c", dizi[i]);			
	}
		
	printf("\nSkor: %d", kayit.skor);	
	printf("\n%s", kayit.isim);
}

void dosyaKayit() {
	
	FILE *pKayit;
	
	pKayit = fopen("kayit.txt", "w");
	
	fprintf(pKayit, "%s %d", kayit.isim, kayit.skor);
	
	fclose(pKayit);
}

void skorYazdir() {
	
	FILE *pKayit;
	
	pKayit = fopen("kayit.txt", "r");
	
	char dosyaIsim[20];
	int  dosyaSkor;
	
	fscanf(pKayit, "%s %d", dosyaIsim, &dosyaSkor);
	
	fclose(pKayit);
	
	printf("\nisim: %s skor: %d", dosyaIsim, dosyaSkor);
}

main() {
	
	kayit.skor = 0;
	location.x = 0;
	
	printf("isim: ");
	gets(kayit.isim);
	
	while(true) {
		
		usleep(400000);
		ilerle();
		harita();
		dosyaKayit();	
		
		if(kayit.skor == 2) {
			
			skorYazdir();
			
			return 0;			
		}			
	}		
}
